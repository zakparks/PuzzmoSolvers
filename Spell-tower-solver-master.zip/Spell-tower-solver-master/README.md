Spell Tower Solver
==================

Demo <a href="http://stringham.me/solver">here</a>


About
-------------------
This was my first javascript project I built. Thus, it doesn't have the prettiest code. Last time I checked it wasn't working in internet explorer. 

It is based off of the spelltower game on ios, althought it can be used to solve boggle boards and similar word games.